/* ===================================================
   APEX — HISTORY SCREEN
   Calendar, monthly stats, session list
   =================================================== */

let historyMonth = new Date().getMonth();
let historyYear = new Date().getFullYear();
let selectedDay = null;

function renderHistory() {
  renderCalendar();
  renderMonthStats();
  renderHistoryList();
}

// ===== CALENDAR =====
function renderCalendar() {
  const monthNames = ['Janvier','Février','Mars','Avril','Mai','Juin',
                      'Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  document.getElementById('month-label').textContent = `${monthNames[historyMonth]} ${historyYear}`;

  const sessions = DB.getSessionsByMonth(historyYear, historyMonth);
  const workoutDays = new Set(sessions.map(s => new Date(s.date).getDate()));

  const firstDay = new Date(historyYear, historyMonth, 1);
  const lastDay = new Date(historyYear, historyMonth + 1, 0);
  const startDow = (firstDay.getDay() + 6) % 7; // Mon=0

  const today = new Date();

  let html = '';

  // Padding from previous month
  const prevLastDay = new Date(historyYear, historyMonth, 0).getDate();
  for (let i = startDow - 1; i >= 0; i--) {
    html += `<div class="cal-day other-month">${prevLastDay - i}</div>`;
  }

  // Days of month
  for (let d = 1; d <= lastDay.getDate(); d++) {
    const isToday = d === today.getDate() && historyMonth === today.getMonth() && historyYear === today.getFullYear();
    const hasWorkout = workoutDays.has(d);
    const isSelected = selectedDay === d;
    html += `<div class="cal-day
      ${isToday ? 'today' : ''}
      ${hasWorkout ? 'has-workout' : ''}
      ${isSelected ? 'selected' : ''}"
      onclick="selectDay(${d})">${d}</div>`;
  }

  // Padding to next month
  const remaining = (7 - ((startDow + lastDay.getDate()) % 7)) % 7;
  for (let d = 1; d <= remaining; d++) {
    html += `<div class="cal-day other-month">${d}</div>`;
  }

  document.getElementById('cal-grid').innerHTML = html;
}

function selectDay(day) {
  selectedDay = selectedDay === day ? null : day;
  renderCalendar();
  renderHistoryList();
}

function changeMonth(delta) {
  historyMonth += delta;
  if (historyMonth > 11) { historyMonth = 0; historyYear++; }
  if (historyMonth < 0)  { historyMonth = 11; historyYear--; }
  selectedDay = null;
  renderHistory();
}

// ===== MONTHLY STATS =====
function renderMonthStats() {
  const sessions = DB.getSessionsByMonth(historyYear, historyMonth);
  const totalSessions = sessions.length;
  const totalTime = sessions.reduce((s, x) => s + (x.duration || 0), 0);
  const totalKcal = sessions.reduce((s, x) => s + (x.kcal || 0), 0);

  const hours = Math.floor(totalTime / 3600);
  const mins = Math.floor((totalTime % 3600) / 60);
  const timeStr = hours > 0 ? `${hours}h${mins.toString().padStart(2,'0')}` : `${mins}min`;

  document.getElementById('month-stats').innerHTML = `
    <div class="month-stat">
      <div class="month-stat-val" style="color:var(--accent2)">${totalSessions}</div>
      <div class="month-stat-lbl">Séances</div>
    </div>
    <div class="month-stat">
      <div class="month-stat-val" style="color:var(--green)">${timeStr || '0min'}</div>
      <div class="month-stat-lbl">Durée</div>
    </div>
    <div class="month-stat">
      <div class="month-stat-val" style="color:var(--orange)">${totalKcal.toLocaleString('fr')}</div>
      <div class="month-stat-lbl">kcal</div>
    </div>
  `;
}

// ===== HISTORY LIST =====
function renderHistoryList() {
  const el = document.getElementById('history-list');
  let sessions = DB.getSessionsByMonth(historyYear, historyMonth);

  if (selectedDay !== null) {
    sessions = sessions.filter(s => new Date(s.date).getDate() === selectedDay);
  }

  sessions.sort((a, b) => new Date(b.date) - new Date(a.date));

  if (sessions.length === 0) {
    el.innerHTML = `
      <div class="empty-state" style="margin:0 16px">
        <div class="empty-icon">${selectedDay ? '📅' : '🏅'}</div>
        <div class="empty-text">${selectedDay
          ? `Aucune séance le ${selectedDay}`
          : 'Aucune séance ce mois'}</div>
      </div>`;
    return;
  }

  el.innerHTML = sessions.map(s => {
    const sport = SPORT_TYPES[s.sport] || {};
    const chips = buildSessionChips(s);
    const time = new Date(s.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const date = new Date(s.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    return `
      <div class="history-item" onclick="showSessionDetail('${s.id}')">
        <div class="history-icon">${sport.emoji || '🏃'}</div>
        <div class="history-info">
          <div class="history-name">${sport.name || s.sport}</div>
          <div class="history-date">${capitalize(date)} · ${time}</div>
          <div class="history-stats">
            ${chips.map(c => `<span class="history-stat">${c}</span>`).join('')}
          </div>
        </div>
        <div style="color:var(--text3)">${s.rating ? '⭐'.repeat(s.rating) : ''}</div>
      </div>`;
  }).join('');
}

function buildSessionChips(s) {
  const chips = [];
  if (s.duration) chips.push(formatDuration(s.duration));
  if (s.kcal) chips.push(`🔥 ${s.kcal}`);
  if (s.distance) chips.push(`📏 ${s.distance}km`);
  if (s.totalVolume) chips.push(`⚖️ ${s.totalVolume}kg`);
  if (s.exercises && s.exercises.length) chips.push(`💪 ${s.exercises.length}ex`);
  if (s.lapsCount) chips.push(`🔄 ${s.lapsCount}×${s.poolLength || 25}m`);
  return chips.slice(0, 4);
}

/* ===================================================
   APEX — DATA LAYER
   Exercises database, sport config, localStorage API
   =================================================== */

// ===== SPORT TYPES CONFIG =====
const SPORT_TYPES = {
  muscu: {
    id: 'muscu', name: 'Musculation', emoji: '🏋️',
    color: '#5c6cff', colorDim: 'rgba(92,108,255,0.15)',
    type: 'strength',
    desc: 'Haltères, barres et machines',
    tags: ['Force', 'Masse', 'Hypertrophie'],
    kcalPerMin: 6,
  },
  calisthenics: {
    id: 'calisthenics', name: 'Poids de corps', emoji: '🤸',
    color: '#00e5aa', colorDim: 'rgba(0,229,170,0.15)',
    type: 'strength',
    desc: 'Tractions, dips, pompes, gainage',
    tags: ['Force', 'Mobilité', 'Coordination'],
    kcalPerMin: 7,
  },
  running: {
    id: 'running', name: 'Running', emoji: '🏃',
    color: '#ff7040', colorDim: 'rgba(255,112,64,0.15)',
    type: 'cardio',
    desc: 'Course à pied, trail, piste',
    tags: ['Cardio', 'Endurance', 'Calories'],
    kcalPerMin: 10,
    inputs: [
      { key: 'distance', label: '📏 Distance', unit: 'km', step: '0.1' },
      { key: 'heartRate', label: '❤️ FC moy.', unit: 'bpm', step: '1' },
    ]
  },
  velo: {
    id: 'velo', name: 'Vélo', emoji: '🚴',
    color: '#3d9eff', colorDim: 'rgba(61,158,255,0.15)',
    type: 'cardio',
    desc: 'Route, VTT, home-trainer',
    tags: ['Cardio', 'Puissance', 'Endurance'],
    kcalPerMin: 8,
    inputs: [
      { key: 'distance', label: '📏 Distance', unit: 'km', step: '0.1' },
      { key: 'speed', label: '⚡ Vitesse moy.', unit: 'km/h', step: '0.5' },
      { key: 'power', label: '💪 Puissance moy.', unit: 'W', step: '1' },
      { key: 'heartRate', label: '❤️ FC moy.', unit: 'bpm', step: '1' },
    ]
  },
  natation: {
    id: 'natation', name: 'Natation', emoji: '🏊',
    color: '#00b8d4', colorDim: 'rgba(0,184,212,0.15)',
    type: 'cardio',
    desc: 'Nage libre, brasse, dos, papillon',
    tags: ['Cardio', 'Full-body', 'Récup'],
    kcalPerMin: 9,
    inputs: []
  },
  gainage: {
    id: 'gainage', name: 'Gainage', emoji: '🧘',
    color: '#a78bfa', colorDim: 'rgba(167,139,250,0.15)',
    type: 'strength',
    desc: 'Core, planche, abdos, mobilité',
    tags: ['Core', 'Stabilité', 'Posture'],
    kcalPerMin: 4,
  },
};

// ===== EXERCISES DATABASE =====
const EXERCISES_DB_ARR = [
  // POITRINE
  { id:'bench_press', name:'Développé couché', emoji:'🏋️', cat:'Poitrine', muscles:['Pectoraux','Triceps','Épaules'], sport:['muscu'] },
  { id:'incline_press', name:'Développé incliné', emoji:'🏋️', cat:'Poitrine', muscles:['Pectoraux sup.','Triceps'], sport:['muscu'] },
  { id:'dips_chest', name:'Dips (buste penché)', emoji:'⬇️', cat:'Poitrine', muscles:['Pectoraux','Triceps'], sport:['muscu','calisthenics'] },
  { id:'chest_fly', name:'Écarté haltères', emoji:'🦅', cat:'Poitrine', muscles:['Pectoraux'], sport:['muscu'] },
  { id:'pushup', name:'Pompes', emoji:'💪', cat:'Poitrine', muscles:['Pectoraux','Triceps','Core'], sport:['calisthenics','muscu'] },
  { id:'diamond_pushup', name:'Pompes diamant', emoji:'💎', cat:'Poitrine', muscles:['Triceps','Pectoraux'], sport:['calisthenics'] },
  { id:'archer_pushup', name:'Pompes archer', emoji:'🏹', cat:'Poitrine', muscles:['Pectoraux','Épaules'], sport:['calisthenics'] },
  // DOS
  { id:'pullup', name:'Tractions', emoji:'⬆️', cat:'Dos', muscles:['Grand dorsal','Biceps'], sport:['calisthenics','muscu'] },
  { id:'chinup', name:'Chin-ups', emoji:'🔝', cat:'Dos', muscles:['Grand dorsal','Biceps'], sport:['calisthenics'] },
  { id:'row_bar', name:'Rowing barre', emoji:'🚣', cat:'Dos', muscles:['Grand dorsal','Rhomboïdes'], sport:['muscu'] },
  { id:'lat_pulldown', name:'Tirage poulie haute', emoji:'⬇️', cat:'Dos', muscles:['Grand dorsal','Biceps'], sport:['muscu'] },
  { id:'seated_row', name:'Rowing assis machine', emoji:'🪑', cat:'Dos', muscles:['Grand dorsal','Rhomboïdes'], sport:['muscu'] },
  { id:'deadlift', name:'Soulevé de terre', emoji:'🏋️', cat:'Dos', muscles:['Ischios','Lombaires','Fessiers','Trapèzes'], sport:['muscu'] },
  { id:'australian_row', name:'Rowing australien', emoji:'🦘', cat:'Dos', muscles:['Grand dorsal','Biceps','Core'], sport:['calisthenics'] },
  // ÉPAULES
  { id:'ohp', name:'Développé militaire', emoji:'🏋️', cat:'Épaules', muscles:['Deltoïdes','Triceps'], sport:['muscu'] },
  { id:'lateral_raise', name:'Élévations latérales', emoji:'↔️', cat:'Épaules', muscles:['Deltoïde latéral'], sport:['muscu'] },
  { id:'front_raise', name:'Élévations frontales', emoji:'⬆️', cat:'Épaules', muscles:['Deltoïde antérieur'], sport:['muscu'] },
  { id:'facepull', name:'Face pull', emoji:'🎯', cat:'Épaules', muscles:['Deltoïde post.','Rotateurs'], sport:['muscu'] },
  { id:'pike_pushup', name:'Pompes en pike', emoji:'🔺', cat:'Épaules', muscles:['Deltoïdes','Triceps'], sport:['calisthenics'] },
  { id:'handstand_pushup', name:'Pompes en équilibre', emoji:'🙃', cat:'Épaules', muscles:['Deltoïdes','Triceps','Core'], sport:['calisthenics'] },
  // BRAS
  { id:'bicep_curl', name:'Curl biceps', emoji:'💪', cat:'Bras', muscles:['Biceps'], sport:['muscu'] },
  { id:'hammer_curl', name:'Curl marteau', emoji:'🔨', cat:'Bras', muscles:['Biceps','Brachioradial'], sport:['muscu'] },
  { id:'skull_crusher', name:'Skull crusher', emoji:'💀', cat:'Bras', muscles:['Triceps'], sport:['muscu'] },
  { id:'tricep_dips', name:'Dips triceps', emoji:'⬇️', cat:'Bras', muscles:['Triceps'], sport:['calisthenics'] },
  { id:'tricep_pushdown', name:'Pushdown poulie', emoji:'⬇️', cat:'Bras', muscles:['Triceps'], sport:['muscu'] },
  // JAMBES
  { id:'squat', name:'Squat', emoji:'🦵', cat:'Jambes', muscles:['Quadriceps','Fessiers','Ischios'], sport:['muscu'] },
  { id:'leg_press', name:'Leg press', emoji:'🦵', cat:'Jambes', muscles:['Quadriceps','Fessiers'], sport:['muscu'] },
  { id:'lunges', name:'Fentes', emoji:'🚶', cat:'Jambes', muscles:['Quadriceps','Fessiers','Ischios'], sport:['muscu','calisthenics'] },
  { id:'rdl', name:'Soulevé roumain', emoji:'🏋️', cat:'Jambes', muscles:['Ischios','Fessiers'], sport:['muscu'] },
  { id:'leg_curl', name:'Leg curl', emoji:'🦵', cat:'Jambes', muscles:['Ischios'], sport:['muscu'] },
  { id:'leg_extension', name:'Leg extension', emoji:'🦵', cat:'Jambes', muscles:['Quadriceps'], sport:['muscu'] },
  { id:'calf_raise', name:'Mollets debout', emoji:'🦶', cat:'Jambes', muscles:['Mollets'], sport:['muscu','calisthenics'] },
  { id:'pistol_squat', name:'Squat pistol', emoji:'🎯', cat:'Jambes', muscles:['Quadriceps','Fessiers','Core'], sport:['calisthenics'] },
  { id:'glute_bridge', name:'Hip thrust', emoji:'🍑', cat:'Jambes', muscles:['Fessiers','Ischios'], sport:['muscu','calisthenics'] },
  // CORE / GAINAGE
  { id:'plank', name:'Planche frontale', emoji:'🧘', cat:'Core', muscles:['Transverse','Core'], sport:['gainage','calisthenics'] },
  { id:'side_plank', name:'Planche latérale', emoji:'↔️', cat:'Core', muscles:['Obliques','Core'], sport:['gainage','calisthenics'] },
  { id:'crunch', name:'Crunchs', emoji:'🔄', cat:'Core', muscles:['Grand droit'], sport:['gainage','calisthenics'] },
  { id:'leg_raise', name:'Levée de jambes', emoji:'⬆️', cat:'Core', muscles:['Bas du ventre'], sport:['gainage','calisthenics'] },
  { id:'russian_twist', name:'Russian twist', emoji:'🌀', cat:'Core', muscles:['Obliques'], sport:['gainage','calisthenics'] },
  { id:'mountain_climber', name:'Mountain climbers', emoji:'🏔️', cat:'Core', muscles:['Core','Cardio'], sport:['gainage','calisthenics'] },
  { id:'hollow_hold', name:'Hollow body', emoji:'🍌', cat:'Core', muscles:['Core complet'], sport:['gainage','calisthenics'] },
  { id:'ab_wheel', name:'Roue abdominale', emoji:'⭕', cat:'Core', muscles:['Grand droit','Transverse'], sport:['gainage','muscu'] },
  { id:'superman', name:'Superman', emoji:'🦸', cat:'Core', muscles:['Lombaires','Érecteurs'], sport:['gainage'] },
  { id:'bird_dog', name:'Bird dog', emoji:'🐦', cat:'Core', muscles:['Core','Stabilisation'], sport:['gainage'] },
  { id:'dead_bug', name:'Dead bug', emoji:'🪲', cat:'Core', muscles:['Transverse','Core'], sport:['gainage'] },
  // CARDIO / POLYARTICULAIRES
  { id:'burpee', name:'Burpees', emoji:'💥', cat:'Cardio', muscles:['Full body'], sport:['calisthenics','gainage'] },
  { id:'jump_squat', name:'Squat sauté', emoji:'⬆️', cat:'Cardio', muscles:['Quadriceps','Fessiers','Cardio'], sport:['calisthenics'] },
  { id:'box_jump', name:'Box jump', emoji:'📦', cat:'Cardio', muscles:['Quadriceps','Fessiers'], sport:['calisthenics'] },
  { id:'kettlebell_swing', name:'Kettlebell swing', emoji:'🔔', cat:'Cardio', muscles:['Fessiers','Core','Dos'], sport:['muscu'] },
];

// ===== LOCAL STORAGE API =====
const DB = {
  SESSIONS_KEY: 'apex_sessions',
  PROFIL_KEY: 'apex_profil',
  SETTINGS_KEY: 'apex_settings',
  STREAK_KEY: 'apex_streak',

  getSessions() {
    try { return JSON.parse(localStorage.getItem(this.SESSIONS_KEY) || '[]'); }
    catch { return []; }
  },

  saveSession(session) {
    const sessions = this.getSessions();
    sessions.unshift(session);
    localStorage.setItem(this.SESSIONS_KEY, JSON.stringify(sessions));
    this.updateStreak();
  },

  deleteSession(id) {
    const sessions = this.getSessions().filter(s => s.id !== id);
    localStorage.setItem(this.SESSIONS_KEY, JSON.stringify(sessions));
    this.updateStreak();
  },

  getProfil() {
    try { return JSON.parse(localStorage.getItem(this.PROFIL_KEY) || '{}'); }
    catch { return {}; }
  },

  saveProfil(profil) {
    localStorage.setItem(this.PROFIL_KEY, JSON.stringify(profil));
  },

  getSettings() {
    try {
      return JSON.parse(localStorage.getItem(this.SETTINGS_KEY) || JSON.stringify({
        vibration: true, sound: true, dark: true, weeklyGoal: 3
      }));
    } catch { return { vibration: true, sound: true, dark: true, weeklyGoal: 3 }; }
  },

  saveSettings(settings) {
    localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(settings));
  },

  updateStreak() {
    const sessions = this.getSessions();
    if (!sessions.length) {
      localStorage.setItem(this.STREAK_KEY, JSON.stringify({ current: 0, best: 0 }));
      return;
    }
    const today = new Date(); today.setHours(0,0,0,0);
    const workoutDays = [...new Set(sessions.map(s => {
      const d = new Date(s.date); d.setHours(0,0,0,0); return d.getTime();
    }))].sort((a,b) => b-a);

    let streak = 0;
    let checkDate = today.getTime();
    for (const day of workoutDays) {
      if (day === checkDate || day === checkDate - 86400000) {
        streak++;
        checkDate = day - 86400000;
      } else if (day < checkDate - 86400000) break;
    }
    const prev = this.getStreak();
    localStorage.setItem(this.STREAK_KEY, JSON.stringify({
      current: streak, best: Math.max(streak, prev.best || 0)
    }));
  },

  getStreak() {
    try { return JSON.parse(localStorage.getItem(this.STREAK_KEY) || '{"current":0,"best":0}'); }
    catch { return { current: 0, best: 0 }; }
  },

  getSessionsByMonth(year, month) {
    return this.getSessions().filter(s => {
      const d = new Date(s.date);
      return d.getFullYear() === year && d.getMonth() === month;
    });
  },

  getSessionsByPeriod(period) {
    const sessions = this.getSessions();
    if (period === 'all') return sessions;
    const now = new Date();
    const cutoff = new Date();
    if (period === 'week') cutoff.setDate(now.getDate() - 7);
    else if (period === 'month') cutoff.setDate(now.getDate() - 30);
    else if (period === 'year') cutoff.setFullYear(now.getFullYear() - 1);
    return sessions.filter(s => new Date(s.date) >= cutoff);
  },

  resetAll() {
    [this.SESSIONS_KEY, this.PROFIL_KEY, this.SETTINGS_KEY, this.STREAK_KEY]
      .forEach(k => localStorage.removeItem(k));
  },

  genId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
  }
};

// ===== UTILITIES =====
function formatDuration(seconds) {
  if (!seconds || seconds <= 0) return '0min';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h${m.toString().padStart(2,'0')}`;
  if (m > 0) return `${m}min${s > 0 ? s+'s' : ''}`;
  return `${s}s`;
}

function formatTimer(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
  return `${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
}

function formatDate(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  const yest = new Date();
  yest.setDate(now.getDate() - 1);
  const dn = new Date(d); dn.setHours(0,0,0,0);
  const nn = new Date(now); nn.setHours(0,0,0,0);
  const yn = new Date(yest); yn.setHours(0,0,0,0);
  if (dn.getTime() === nn.getTime()) return "Aujourd'hui";
  if (dn.getTime() === yn.getTime()) return 'Hier';
  return d.toLocaleDateString('fr-FR', { weekday:'long', day:'numeric', month:'long' });
}

function formatDateShort(dateStr) {
  return new Date(dateStr).toLocaleDateString('fr-FR', { day:'numeric', month:'short' });
}

function estimateKcal(sportId, durationSeconds, weight = 75) {
  const sport = SPORT_TYPES[sportId];
  if (!sport) return 0;
  return Math.round(sport.kcalPerMin * (durationSeconds / 60) * (weight / 70));
}

function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function getExercisesForSport(sportId) {
  return EXERCISES_DB_ARR.filter(e => !sportId || e.sport.includes(sportId));
}

function getExerciseById(id) {
  return EXERCISES_DB_ARR.find(e => e.id === id);
}

function getAllCategories() {
  return [...new Set(EXERCISES_DB_ARR.map(e => e.cat))];
}

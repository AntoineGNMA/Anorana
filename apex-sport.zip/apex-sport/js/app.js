/* ===================================================
   APEX — MAIN APP
   Navigation, splash, home screen, profil
   =================================================== */

// ===== STATE =====
let currentScreen = 'screen-home';
let currentRating = 0;
let pendingWorkout = null; // workout to save after summary

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  // Splash animation
  setTimeout(() => {
    document.getElementById('splash').style.opacity = '0';
    document.getElementById('splash').style.transition = 'opacity 0.4s ease';
    setTimeout(() => {
      document.getElementById('splash').classList.add('hidden');
      document.getElementById('main-app').classList.remove('hidden');
      initApp();
    }, 400);
  }, 2000);

  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
});

function initApp() {
  renderWorkoutTypeList();
  renderHome();
  renderHistory();
  renderStats('week');
  loadProfil();
}

// ===== NAVIGATION =====
function showScreen(id) {
  // Hide all screens
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  currentScreen = id;

  // Update nav
  const navScreens = ['screen-home', 'screen-new', 'screen-history', 'screen-stats'];
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.screen === id) btn.classList.add('active');
  });

  // Refresh on switch
  if (id === 'screen-home') renderHome();
  if (id === 'screen-history') renderHistory();
  if (id === 'screen-stats') renderStats(currentPeriod || 'week');

  // Show/hide nav
  const hideNav = ['screen-active-strength', 'screen-active-cardio'];
  document.getElementById('bottom-nav').style.display = hideNav.includes(id) ? 'none' : 'flex';
}

// ===== HOME SCREEN =====
function renderHome() {
  const streak = DB.getStreak();
  document.getElementById('streak-count').textContent = streak.current;
  document.getElementById('streak-best').textContent = `${streak.best} meilleur`;

  const allSessions = DB.getSessions();
  const profil = DB.getProfil();
  const weight = profil.weight || 75;

  // Total stats
  const totalKcal = allSessions.reduce((sum, s) => sum + (s.kcal || 0), 0);
  const totalTime = allSessions.reduce((sum, s) => sum + (s.duration || 0), 0);
  const totalDist = allSessions.reduce((sum, s) => sum + (parseFloat(s.distance) || 0), 0);

  document.getElementById('stat-total').textContent = allSessions.length;
  document.getElementById('stat-time').textContent = totalTime >= 3600
    ? `${Math.floor(totalTime / 3600)}h` : `${Math.floor(totalTime / 60)}min`;
  document.getElementById('stat-kcal').textContent = totalKcal.toLocaleString('fr');
  document.getElementById('stat-dist').textContent = totalDist > 0
    ? `${totalDist.toFixed(0)}km` : '0km';

  // Weekly chart
  renderWeeklyChart();

  // Recent sessions
  const recentEl = document.getElementById('recent-sessions');
  const recent = allSessions.slice(0, 5);
  if (recent.length === 0) {
    recentEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🏅</div>
        <div class="empty-text">Aucune séance pour l'instant.<br>C'est le moment de commencer !</div>
      </div>`;
  } else {
    recentEl.innerHTML = recent.map(s => {
      const sport = SPORT_TYPES[s.sport] || {};
      const chips = buildChips(s);
      const stars = s.rating ? '⭐'.repeat(s.rating) : '';
      return `
        <div class="session-card" onclick="showSessionDetail('${s.id}')">
          <div class="session-icon">${sport.emoji || '🏃'}</div>
          <div class="session-info">
            <div class="session-name">${sport.name || s.sport}</div>
            <div class="session-date">${formatDate(s.date)}</div>
            <div class="session-chips">
              ${chips.map(c => `<span class="session-chip">${c}</span>`).join('')}
            </div>
          </div>
          <div class="session-rating">${stars}</div>
        </div>`;
    }).join('');
  }
}

function buildChips(session) {
  const chips = [];
  if (session.duration) chips.push(formatDuration(session.duration));
  if (session.kcal) chips.push(`${session.kcal} kcal`);
  if (session.distance) chips.push(`${session.distance} km`);
  if (session.totalVolume) chips.push(`${session.totalVolume} kg`);
  if (session.exercises && session.exercises.length > 0) {
    chips.push(`${session.exercises.length} ex.`);
  }
  return chips.slice(0, 3);
}

function renderWeeklyChart() {
  const el = document.getElementById('weekly-chart');
  const days = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
  const sessions = DB.getSessions();

  const today = new Date();
  const dayOfWeek = (today.getDay() + 6) % 7; // Monday = 0

  const weekDays = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - dayOfWeek + i);
    d.setHours(0, 0, 0, 0);
    weekDays.push(d);
  }

  // Max duration for scaling
  const durations = weekDays.map(day => {
    return sessions.filter(s => {
      const sd = new Date(s.date);
      sd.setHours(0, 0, 0, 0);
      return sd.getTime() === day.getTime();
    }).reduce((sum, s) => sum + (s.duration || 0), 0);
  });
  const maxDur = Math.max(...durations, 1800); // min 30min scale

  el.innerHTML = weekDays.map((day, i) => {
    const isToday = i === dayOfWeek;
    const hasWorkout = durations[i] > 0;
    const pct = hasWorkout ? Math.max(8, (durations[i] / maxDur) * 100) : 0;
    return `
      <div class="week-bar-wrap">
        <div class="week-bar-col">
          <div class="week-bar-fill ${hasWorkout ? 'has-workout' : ''}" style="height:${pct}%"></div>
        </div>
        <div class="week-bar-lbl ${isToday ? 'today' : ''}">${days[i]}</div>
      </div>`;
  }).join('');
}

// ===== WORKOUT TYPE LIST =====
function renderWorkoutTypeList() {
  const el = document.getElementById('workout-type-list');
  el.innerHTML = Object.values(SPORT_TYPES).map(sport => `
    <div class="wt-card" onclick="startWorkout('${sport.id}')">
      <div class="wt-icon" style="background:${sport.colorDim}; color:${sport.color}">${sport.emoji}</div>
      <div class="wt-info">
        <div class="wt-name">${sport.name}</div>
        <div class="wt-desc">${sport.desc}</div>
        <div class="wt-tags">
          ${sport.tags.map(t => `<span class="wt-tag">${t}</span>`).join('')}
        </div>
      </div>
      <div class="wt-arrow">›</div>
    </div>
  `).join('');
}

// ===== SESSION DETAIL =====
function showSessionDetail(sessionId) {
  const session = DB.getSessions().find(s => s.id === sessionId);
  if (!session) return;
  const sport = SPORT_TYPES[session.sport] || {};

  // Show summary modal in readonly mode
  pendingWorkout = null;
  const modal = document.getElementById('modal-summary');
  document.getElementById('summary-emoji').textContent = sport.emoji || '🏃';
  document.getElementById('summary-sport').textContent = sport.name || session.sport;
  document.getElementById('summary-title').textContent = formatDate(session.date);

  buildSummaryStats(session);
  setRatingDisplay(session.rating || 0);

  modal.classList.remove('hidden');

  // Change buttons for detail view
  document.querySelector('.summary-save-btn').textContent = '✓ Fermer';
  document.querySelector('.summary-save-btn').onclick = () => closeModal('modal-summary');
  document.querySelector('.summary-discard-btn').textContent = '🗑 Supprimer';
  document.querySelector('.summary-discard-btn').onclick = () => {
    if (confirm('Supprimer cette séance ?')) {
      DB.deleteSession(sessionId);
      closeModal('modal-summary');
      renderHome();
      renderHistory();
      showToast('Séance supprimée');
    }
  };
}

// ===== PROFIL =====
function loadProfil() {
  const p = DB.getProfil();
  const s = DB.getSettings();

  if (p.firstname) {
    document.getElementById('profil-firstname').value = p.firstname;
    document.getElementById('profil-name-display').textContent = p.firstname;
    document.querySelector('.user-name').innerHTML = `${p.firstname} <span class="accent">APEX</span>`;
    document.querySelector('.profil-avatar-big').textContent = p.firstname[0].toUpperCase();
    document.querySelector('.avatar').textContent = p.firstname[0].toUpperCase();
  }
  if (p.weight) document.getElementById('profil-weight').value = p.weight;
  if (p.height) document.getElementById('profil-height').value = p.height;
  if (p.age) document.getElementById('profil-age').value = p.age;
  if (p.goal) document.getElementById('profil-goal').value = p.goal;
  if (s.weeklyGoal) document.getElementById('goal-display').textContent = s.weeklyGoal;

  // Toggles
  updateToggle('vibration', s.vibration);
  updateToggle('sound', s.sound);
  updateToggle('dark', s.dark !== false);
}

function saveProfil() {
  const profil = {
    firstname: document.getElementById('profil-firstname').value.trim(),
    weight: parseFloat(document.getElementById('profil-weight').value) || 75,
    height: parseFloat(document.getElementById('profil-height').value) || 175,
    age: parseInt(document.getElementById('profil-age').value) || 25,
    goal: document.getElementById('profil-goal').value,
  };
  DB.saveProfil(profil);

  if (profil.firstname) {
    document.getElementById('profil-name-display').textContent = profil.firstname;
    document.querySelector('.user-name').innerHTML = `${profil.firstname} <span class="accent">APEX</span>`;
    document.querySelector('.profil-avatar-big').textContent = profil.firstname[0].toUpperCase();
    document.querySelector('.avatar').textContent = profil.firstname[0].toUpperCase();
  }
  showToast('✅ Profil enregistré !');
}

function editName() {
  const el = document.getElementById('profil-firstname');
  el.focus();
  el.select();
}

function changeGoal(delta) {
  const s = DB.getSettings();
  s.weeklyGoal = Math.max(1, Math.min(7, (s.weeklyGoal || 3) + delta));
  DB.saveSettings(s);
  document.getElementById('goal-display').textContent = s.weeklyGoal;
}

function toggleSetting(key) {
  const s = DB.getSettings();
  s[key] = !s[key];
  DB.saveSettings(s);
  updateToggle(key, s[key]);
}

function updateToggle(key, val) {
  const el = document.getElementById(`toggle-${key}`);
  if (!el) return;
  if (val) el.classList.add('active');
  else el.classList.remove('active');
}

function exportData() {
  const data = {
    sessions: DB.getSessions(),
    profil: DB.getProfil(),
    settings: DB.getSettings(),
    streak: DB.getStreak(),
    exportDate: new Date().toISOString(),
    version: '1.0',
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `apex-export-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('📤 Export réussi !');
}

function confirmReset() {
  if (confirm('⚠️ Toutes tes données seront effacées. Continuer ?')) {
    DB.resetAll();
    location.reload();
  }
}

// ===== MODALS =====
function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.add('hidden');
  });
});

// ===== TOAST =====
function showToast(msg, duration = 2200) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), duration);
}

// ===== RATING =====
function setRating(val) {
  currentRating = val;
  setRatingDisplay(val);
}

function setRatingDisplay(val) {
  document.querySelectorAll('.rating-stars span').forEach((s, i) => {
    s.classList.toggle('lit', i < val);
    s.textContent = i < val ? '⭐' : '☆';
  });
}

// ===== SUMMARY =====
function buildSummaryStats(workout) {
  const el = document.getElementById('summary-stats');
  const stats = [];

  stats.push({ val: formatTimer(workout.duration || 0), lbl: 'Durée' });
  if (workout.kcal) stats.push({ val: `${workout.kcal}`, lbl: 'kcal' });
  if (workout.distance) stats.push({ val: `${workout.distance}`, lbl: 'km' });
  if (workout.totalVolume) stats.push({ val: `${workout.totalVolume}`, lbl: 'kg vol.' });
  if (workout.exercises) stats.push({ val: `${workout.exercises.length}`, lbl: 'exercices' });
  if (workout.totalSets) stats.push({ val: `${workout.totalSets}`, lbl: 'séries' });
  if (workout.laps && workout.laps.length) stats.push({ val: `${workout.laps.length}`, lbl: 'splits' });
  if (workout.speed) stats.push({ val: `${workout.speed}`, lbl: 'km/h moy' });

  el.innerHTML = stats.slice(0, 4).map(s => `
    <div class="summary-stat">
      <div class="summary-stat-val">${s.val}</div>
      <div class="summary-stat-lbl">${s.lbl}</div>
    </div>
  `).join('');
}

function saveWorkout() {
  if (!pendingWorkout) { closeModal('modal-summary'); return; }
  pendingWorkout.rating = currentRating;
  DB.saveSession(pendingWorkout);
  pendingWorkout = null;
  closeModal('modal-summary');
  showScreen('screen-home');
  showToast('🎉 Séance enregistrée !');
}

function discardWorkout() {
  pendingWorkout = null;
  closeModal('modal-summary');
  showScreen('screen-home');
}

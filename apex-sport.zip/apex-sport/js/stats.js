/* ===================================================
   APEX — STATS SCREEN
   Analytics, sport breakdown, personal records
   =================================================== */

let currentPeriod = 'week';

function setPeriod(period, btn) {
  currentPeriod = period;
  document.querySelectorAll('.period-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderStats(period);
}

function renderStats(period) {
  const sessions = DB.getSessionsByPeriod(period);

  renderBigStats(sessions);
  renderSportBreakdown(sessions);
  renderPersonalRecords();
  renderVolumeChart(period);
}

// ===== BIG STATS =====
function renderBigStats(sessions) {
  const totalSessions = sessions.length;
  const totalTime = sessions.reduce((s, x) => s + (x.duration || 0), 0);
  const totalKcal = sessions.reduce((s, x) => s + (x.kcal || 0), 0);
  const totalDist = sessions.reduce((s, x) => s + (parseFloat(x.distance) || 0), 0);
  const totalVol = sessions.reduce((s, x) => s + (x.totalVolume || 0), 0);
  const avgDur = totalSessions ? Math.floor(totalTime / totalSessions) : 0;

  const h = Math.floor(totalTime / 3600);
  const m = Math.floor((totalTime % 3600) / 60);
  const timeStr = h > 0 ? `${h}h${m.toString().padStart(2,'0')}` : `${m}min`;

  document.getElementById('big-stats-grid').innerHTML = `
    <div class="big-stat-card accent-bar">
      <div class="big-stat-icon">📅</div>
      <div class="big-stat-val">${totalSessions}</div>
      <div class="big-stat-lbl">Séances totales</div>
    </div>
    <div class="big-stat-card green-bar">
      <div class="big-stat-icon">⏱</div>
      <div class="big-stat-val">${timeStr || '0'}</div>
      <div class="big-stat-lbl">Temps d'entraînement</div>
    </div>
    <div class="big-stat-card orange-bar">
      <div class="big-stat-icon">🔥</div>
      <div class="big-stat-val">${totalKcal.toLocaleString('fr')}</div>
      <div class="big-stat-lbl">Calories brûlées</div>
    </div>
    <div class="big-stat-card blue-bar">
      <div class="big-stat-icon">📏</div>
      <div class="big-stat-val">${totalDist > 0 ? totalDist.toFixed(1) : (totalVol > 0 ? Math.round(totalVol).toLocaleString('fr') : '0')}</div>
      <div class="big-stat-lbl">${totalDist > 0 ? 'km parcourus' : 'kg volume total'}</div>
    </div>
  `;
}

// ===== SPORT BREAKDOWN =====
function renderSportBreakdown(sessions) {
  const counts = {};
  sessions.forEach(s => {
    counts[s.sport] = (counts[s.sport] || 0) + 1;
  });

  const maxCount = Math.max(...Object.values(counts), 1);
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);

  const el = document.getElementById('sport-breakdown');
  if (sorted.length === 0) {
    el.innerHTML = '<div style="padding:0 0 16px;color:var(--text3);font-size:14px">Aucune donnée pour cette période</div>';
    return;
  }

  el.innerHTML = sorted.map(([sportId, count]) => {
    const sport = SPORT_TYPES[sportId] || { emoji: '🏃', name: sportId, color: '#5c6cff' };
    const pct = (count / maxCount) * 100;
    return `
      <div class="sport-row">
        <div class="sport-row-icon">${sport.emoji}</div>
        <div class="sport-row-info">
          <div class="sport-row-name">${sport.name}</div>
          <div class="sport-bar-bg">
            <div class="sport-bar-fill" style="width:${pct}%; background:${sport.color || 'var(--accent)'}"></div>
          </div>
        </div>
        <div class="sport-row-count">${count}</div>
      </div>
    `;
  }).join('');
}

// ===== PERSONAL RECORDS =====
function renderPersonalRecords() {
  const sessions = DB.getSessions();
  const prs = computePersonalRecords(sessions);
  const el = document.getElementById('pr-list');

  if (prs.length === 0) {
    el.innerHTML = '<div style="padding:0 16px 16px;color:var(--text3);font-size:14px">Complète des séances pour voir tes records !</div>';
    return;
  }

  el.innerHTML = prs.map((pr, i) => `
    <div class="pr-card">
      <div class="pr-medal">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🏅'}</div>
      <div class="pr-info">
        <div class="pr-name">${pr.name}</div>
        <div class="pr-date">${formatDateShort(pr.date)}</div>
      </div>
      <div class="pr-value">${pr.value}</div>
    </div>
  `).join('');
}

function computePersonalRecords(sessions) {
  const prs = [];

  // Longest session
  const longestSession = sessions.reduce((best, s) =>
    !best || (s.duration || 0) > (best.duration || 0) ? s : best, null);
  if (longestSession && longestSession.duration > 0) {
    prs.push({
      name: `Plus longue séance (${SPORT_TYPES[longestSession.sport]?.name || longestSession.sport})`,
      value: formatDuration(longestSession.duration),
      date: longestSession.date
    });
  }

  // Most calories
  const mostKcal = sessions.reduce((best, s) =>
    !best || (s.kcal || 0) > (best.kcal || 0) ? s : best, null);
  if (mostKcal && mostKcal.kcal > 0) {
    prs.push({
      name: 'Max calories en une séance',
      value: `${mostKcal.kcal} kcal`,
      date: mostKcal.date
    });
  }

  // Longest run
  const runs = sessions.filter(s => s.sport === 'running' && s.distance);
  if (runs.length > 0) {
    const bestRun = runs.reduce((best, s) => parseFloat(s.distance) > parseFloat(best.distance) ? s : best);
    prs.push({
      name: '🏃 Plus longue course',
      value: `${parseFloat(bestRun.distance).toFixed(1)} km`,
      date: bestRun.date
    });
  }

  // Most volume
  const strengthSessions = sessions.filter(s => s.totalVolume > 0);
  if (strengthSessions.length > 0) {
    const bestVol = strengthSessions.reduce((best, s) =>
      (s.totalVolume || 0) > (best.totalVolume || 0) ? s : best);
    prs.push({
      name: `💪 Volume record (${SPORT_TYPES[bestVol.sport]?.name || ''})`,
      value: `${bestVol.totalVolume.toLocaleString('fr')} kg`,
      date: bestVol.date
    });
  }

  // Longest ride
  const rides = sessions.filter(s => s.sport === 'velo' && s.distance);
  if (rides.length > 0) {
    const bestRide = rides.reduce((best, s) => parseFloat(s.distance) > parseFloat(best.distance) ? s : best);
    prs.push({
      name: '🚴 Plus longue sortie vélo',
      value: `${parseFloat(bestRide.distance).toFixed(1)} km`,
      date: bestRide.date
    });
  }

  // Most swim laps
  const swims = sessions.filter(s => s.sport === 'natation' && s.lapsCount);
  if (swims.length > 0) {
    const bestSwim = swims.reduce((best, s) =>
      (s.lapsCount || 0) > (best.lapsCount || 0) ? s : best);
    const dist = bestSwim.lapsCount * (bestSwim.poolLength || 25);
    prs.push({
      name: '🏊 Plus longue natation',
      value: `${dist}m (${bestSwim.lapsCount} long.)`,
      date: bestSwim.date
    });
  }

  // Best exercises PRs
  const exercisePRs = computeExercisePRs(sessions);
  prs.push(...exercisePRs.slice(0, 3));

  return prs.slice(0, 8);
}

function computeExercisePRs(sessions) {
  const bests = {};

  sessions.forEach(s => {
    if (!s.exercises) return;
    s.exercises.forEach(ex => {
      ex.sets?.forEach(set => {
        if (!set.done || !set.weight || !set.reps) return;
        const oneRM = set.weight * (1 + set.reps / 30); // Epley formula
        if (!bests[ex.id] || oneRM > bests[ex.id].oneRM) {
          bests[ex.id] = {
            name: ex.name,
            weight: set.weight,
            reps: set.reps,
            oneRM,
            date: s.date
          };
        }
      });
    });
  });

  return Object.values(bests)
    .sort((a, b) => b.oneRM - a.oneRM)
    .map(b => ({
      name: `🏋️ ${b.name} (1RM est.)`,
      value: `~${Math.round(b.oneRM)} kg`,
      date: b.date
    }));
}

// ===== VOLUME CHART =====
function renderVolumeChart(period) {
  const el = document.getElementById('volume-chart');
  const sessions = DB.getSessions();

  // Build 8 periods
  let periods = [];
  const now = new Date();

  if (period === 'week' || period === 'month') {
    // Last 8 weeks
    for (let i = 7; i >= 0; i--) {
      const start = new Date(now);
      start.setDate(now.getDate() - i * 7 - 7);
      start.setHours(0, 0, 0, 0);
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      end.setHours(23, 59, 59, 999);
      const weekSessions = sessions.filter(s => {
        const d = new Date(s.date);
        return d >= start && d <= end;
      });
      const vol = weekSessions.reduce((sum, s) => sum + (s.totalVolume || 0) + (s.duration ? s.duration / 60 * 2 : 0), 0);
      periods.push({ label: `S${8 - i}`, value: vol });
    }
  } else {
    // Last 8 months
    for (let i = 7; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthSessions = sessions.filter(s => {
        const sd = new Date(s.date);
        return sd.getMonth() === d.getMonth() && sd.getFullYear() === d.getFullYear();
      });
      const vol = monthSessions.reduce((sum, s) => sum + (s.totalVolume || 0) + (s.duration ? s.duration / 60 * 2 : 0), 0);
      const monthNames = ['Jan','Fév','Mar','Avr','Mai','Jun','Jul','Aoû','Sep','Oct','Nov','Déc'];
      periods.push({ label: monthNames[d.getMonth()], value: vol });
    }
  }

  const maxVal = Math.max(...periods.map(p => p.value), 1);

  el.innerHTML = periods.map(p => {
    const pct = Math.max(0, (p.value / maxVal) * 100);
    return `
      <div class="vol-bar-wrap">
        <div class="vol-bar-col">
          <div class="vol-bar-fill" style="height:${pct}%"></div>
        </div>
        <div class="vol-bar-lbl">${p.label}</div>
      </div>
    `;
  }).join('');
}

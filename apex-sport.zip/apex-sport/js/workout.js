/* ===================================================
   APEX — WORKOUT ENGINE
   Strength (muscu/calisthenics/gainage) + Cardio
   =================================================== */

// ===== WORKOUT STATE =====
let activeWorkout = null;
let workoutTimer = null;
let workoutSeconds = 0;
let cardioTimer = null;
let cardioPaused = false;
let cardioSeconds = 0;
let lapStartTime = 0;
let laps = [];
let restTimer = null;
let restRemaining = 0;
let restTotal = 90;
let exerciseFilter = 'Tous';

// ===== START WORKOUT =====
function startWorkout(sportId) {
  const sport = SPORT_TYPES[sportId];
  if (!sport) return;

  activeWorkout = {
    id: DB.genId(),
    sport: sportId,
    date: new Date().toISOString(),
    type: sport.type,
    exercises: [],
    notes: '',
  };

  workoutSeconds = 0;
  cardioSeconds = 0;
  laps = [];
  cardioPaused = false;
  lapStartTime = Date.now();

  if (sport.type === 'strength') {
    startStrengthSession(sport);
  } else {
    startCardioSession(sport);
  }
}

// ===== STRENGTH SESSION =====
function startStrengthSession(sport) {
  document.getElementById('strength-title').textContent = sport.name;
  document.getElementById('exercise-list').innerHTML = '';
  document.getElementById('workout-notes').value = '';
  document.getElementById('strength-kcal').textContent = '0';
  document.getElementById('strength-sets').textContent = '0';
  document.getElementById('strength-vol').textContent = '0';
  updateStrengthTimer();

  showScreen('screen-active-strength');

  // Start timer
  clearInterval(workoutTimer);
  workoutTimer = setInterval(() => {
    workoutSeconds++;
    updateStrengthTimer();
    updateLiveStats();
  }, 1000);
}

function updateStrengthTimer() {
  document.getElementById('strength-timer').textContent = formatTimer(workoutSeconds);
}

function updateLiveStats() {
  const profil = DB.getProfil();
  const sport = activeWorkout ? SPORT_TYPES[activeWorkout.sport] : null;
  const kcal = sport ? estimateKcal(activeWorkout.sport, workoutSeconds, profil.weight) : 0;
  document.getElementById('strength-kcal').textContent = kcal;

  // Count sets
  let totalSets = 0;
  let totalVol = 0;
  document.querySelectorAll('.set-check.done').forEach(() => totalSets++);

  document.querySelectorAll('.exercise-item').forEach(item => {
    item.querySelectorAll('.set-row').forEach(row => {
      const check = row.querySelector('.set-check');
      if (check && check.classList.contains('done')) {
        const reps = parseFloat(row.querySelector('[data-type="reps"]')?.value) || 0;
        const weight = parseFloat(row.querySelector('[data-type="weight"]')?.value) || 0;
        totalVol += reps * weight;
        totalSets++;
      }
    });
  });

  // Recount properly
  totalSets = document.querySelectorAll('.set-check.done').length;
  document.getElementById('strength-sets').textContent = totalSets;
  document.getElementById('strength-vol').textContent = Math.round(totalVol);
}

// ===== EXERCISE MANAGEMENT =====
function openExercisePicker() {
  exerciseFilter = 'Tous';
  renderExercisePicker();
  openModal('modal-exercises');
}

function renderExercisePicker() {
  const sportId = activeWorkout?.sport;
  const cats = ['Tous', ...getAllCategories()];

  // Categories
  document.getElementById('exercise-categories').innerHTML = cats.map(c => `
    <button class="ex-cat-btn ${c === exerciseFilter ? 'active' : ''}"
            onclick="setExerciseFilter('${c}')">${c}</button>
  `).join('');

  // Exercises
  filterExercises(document.getElementById('exercise-search').value);
}

function setExerciseFilter(cat) {
  exerciseFilter = cat;
  renderExercisePicker();
}

function filterExercises(query) {
  const sportId = activeWorkout?.sport;
  let exercises = EXERCISES_DB_ARR;

  if (exerciseFilter !== 'Tous') {
    exercises = exercises.filter(e => e.cat === exerciseFilter);
  }
  if (query) {
    const q = query.toLowerCase();
    exercises = exercises.filter(e =>
      e.name.toLowerCase().includes(q) ||
      (e.muscles || []).some(m => m.toLowerCase().includes(q))
    );
  }

  document.getElementById('exercise-picker-list').innerHTML = exercises.length === 0
    ? '<div style="padding:24px;text-align:center;color:var(--text3)">Aucun exercice trouvé</div>'
    : exercises.map(e => `
      <div class="ex-pick-item" onclick="addExercise('${e.id}')">
        <div class="ex-pick-emoji">${e.emoji}</div>
        <div class="ex-pick-info">
          <div class="ex-pick-name">${e.name}</div>
          <div class="ex-pick-cat">${e.cat} · ${(e.muscles || []).slice(0, 2).join(', ')}</div>
        </div>
        <div class="ex-pick-arrow">›</div>
      </div>
    `).join('');
}

function addExercise(exerciseId) {
  const ex = getExerciseById(exerciseId) || { id: exerciseId, name: exerciseId, emoji: '💪', cat: '' };
  const exItem = createExerciseItem(ex);
  document.getElementById('exercise-list').appendChild(exItem);
  closeModal('modal-exercises');
  document.getElementById('exercise-search').value = '';
}

function createExerciseItem(ex) {
  const itemId = 'ex_' + DB.genId();
  const div = document.createElement('div');
  div.className = 'exercise-item';
  div.id = itemId;
  div.dataset.exId = ex.id;
  div.dataset.exName = ex.name;

  // Determine if timed or reps-based
  const isTimed = ['plank', 'side_plank', 'hollow_hold', 'superman', 'bird_dog', 'dead_bug', 'mountain_climber'].includes(ex.id);

  div.innerHTML = `
    <div class="exercise-item-header">
      <div class="exercise-emoji">${ex.emoji || '💪'}</div>
      <div class="exercise-name-display">${ex.name}</div>
      <button class="del-exercise-btn" onclick="removeExercise('${itemId}')">✕</button>
    </div>
    <div class="sets-table">
      <div class="sets-header-row">
        <span>#</span>
        <span>${isTimed ? 'Durée' : 'Reps'}</span>
        <span>${isTimed ? '' : 'Poids (kg)'}</span>
        <span>RIR</span>
        <span></span>
      </div>
      <div class="sets-body" id="sets_${itemId}"></div>
    </div>
    <button class="add-set-btn" onclick="addSet('${itemId}', ${isTimed})">＋ Série</button>
  `;

  // Add first set
  setTimeout(() => addSet(itemId, isTimed), 0);
  return div;
}

function addSet(itemId, isTimed = false) {
  const setsBody = document.getElementById(`sets_${itemId}`);
  if (!setsBody) return;
  const setNum = setsBody.children.length + 1;
  const prevRow = setsBody.lastElementChild;
  const prevReps = prevRow?.querySelector('[data-type="reps"]')?.value || (isTimed ? '30' : '10');
  const prevWeight = prevRow?.querySelector('[data-type="weight"]')?.value || '0';

  const row = document.createElement('div');
  row.className = 'set-row';
  row.innerHTML = `
    <div class="set-num">${setNum}</div>
    <input class="set-input" type="number" inputmode="decimal" placeholder="${isTimed ? '30s' : '10'}"
           data-type="reps" value="${prevReps}" min="0" />
    <input class="set-input" type="number" inputmode="decimal" placeholder="kg"
           data-type="weight" value="${prevWeight}" min="0"
           ${isTimed ? 'disabled style="opacity:0.3"' : ''} />
    <input class="set-input" type="number" inputmode="decimal" placeholder="0"
           data-type="rir" min="0" max="5" />
    <button class="set-check" onclick="toggleSetDone(this)">✓</button>
  `;
  setsBody.appendChild(row);
  updateLiveStats();
}

function toggleSetDone(btn) {
  btn.classList.toggle('done');
  if (btn.classList.contains('done')) {
    btn.textContent = '✓';
    // Auto-trigger rest timer
    const s = DB.getSettings();
    if (s.vibration && navigator.vibrate) navigator.vibrate([30]);
    showRestTimer();
  } else {
    btn.textContent = '✓';
  }
  updateLiveStats();
}

function removeExercise(itemId) {
  document.getElementById(itemId)?.remove();
  updateLiveStats();
}

// ===== REST TIMER =====
function showRestTimer(duration = 90) {
  restRemaining = duration;
  restTotal = duration;
  openModal('modal-rest');
  updateRestDisplay();
  clearInterval(restTimer);
  restTimer = setInterval(() => {
    restRemaining--;
    updateRestDisplay();
    if (restRemaining <= 0) {
      clearInterval(restTimer);
      closeModal('modal-rest');
      const s = DB.getSettings();
      if (s.vibration && navigator.vibrate) navigator.vibrate([100, 50, 100]);
    }
  }, 1000);
}

function updateRestDisplay() {
  document.getElementById('rest-display').textContent = restRemaining;
  const pct = ((restTotal - restRemaining) / restTotal) * 100;
  document.getElementById('rest-progress').style.width = `${pct}%`;
}

function adjustRest(delta) {
  restRemaining = Math.max(5, restRemaining + delta);
  restTotal = Math.max(restTotal, restRemaining);
  updateRestDisplay();
}

function skipRest() {
  clearInterval(restTimer);
  closeModal('modal-rest');
}

// ===== FINISH STRENGTH =====
function finishWorkout(type) {
  clearInterval(workoutTimer);
  clearInterval(cardioTimer);

  if (type === 'strength') {
    compileStrengthWorkout();
  } else {
    compileCardioWorkout();
  }
}

function compileStrengthWorkout() {
  const profil = DB.getProfil();
  const sport = SPORT_TYPES[activeWorkout.sport];
  const exercises = [];
  let totalSets = 0;
  let totalVol = 0;

  document.querySelectorAll('.exercise-item').forEach(item => {
    const sets = [];
    item.querySelectorAll('.set-row').forEach(row => {
      const reps = parseFloat(row.querySelector('[data-type="reps"]')?.value) || 0;
      const weight = parseFloat(row.querySelector('[data-type="weight"]')?.value) || 0;
      const rir = parseFloat(row.querySelector('[data-type="rir"]')?.value) || null;
      const done = row.querySelector('.set-check')?.classList.contains('done');
      sets.push({ reps, weight, rir, done });
      if (done) {
        totalSets++;
        totalVol += reps * weight;
      }
    });
    exercises.push({
      id: item.dataset.exId,
      name: item.dataset.exName,
      sets,
    });
  });

  const kcal = estimateKcal(activeWorkout.sport, workoutSeconds, profil.weight);

  Object.assign(activeWorkout, {
    duration: workoutSeconds,
    exercises,
    totalSets,
    totalVolume: Math.round(totalVol),
    kcal,
    notes: document.getElementById('workout-notes').value.trim(),
  });

  showSummaryModal();
}

// ===== CARDIO SESSION =====
function startCardioSession(sport) {
  document.getElementById('cardio-title').textContent = sport.name;
  document.getElementById('laps-list').innerHTML = '<div class="empty-laps">Appuie sur "+ Tour" pour enregistrer un split</div>';
  document.getElementById('cardio-notes').value = '';
  laps = [];
  cardioPaused = false;
  cardioSeconds = 0;
  lapStartTime = Date.now();
  document.getElementById('cardio-pause-btn').textContent = '⏸';

  // Build metrics
  buildCardioMetrics(sport);
  buildCardioInputs(sport);

  showScreen('screen-active-cardio');

  clearInterval(cardioTimer);
  cardioTimer = setInterval(() => {
    if (!cardioPaused) {
      cardioSeconds++;
      document.getElementById('cardio-timer').textContent = formatTimer(cardioSeconds);
      updateCardioLiveStats();
    }
  }, 1000);
}

function buildCardioMetrics(sport) {
  const el = document.getElementById('cardio-metrics');
  const profil = DB.getProfil();
  const metricsMap = {
    running: [
      { id: 'cm-dist', val: '0.0', unit: 'km', lbl: 'Distance', cls: 'green' },
      { id: 'cm-pace', val: '--:--', unit: '/km', lbl: 'Allure', cls: 'blue' },
      { id: 'cm-kcal', val: '0', unit: 'kcal', lbl: 'Calories', cls: 'orange' },
      { id: 'cm-hr', val: '--', unit: 'bpm', lbl: 'FC', cls: '' },
    ],
    velo: [
      { id: 'cm-dist', val: '0.0', unit: 'km', lbl: 'Distance', cls: 'green' },
      { id: 'cm-speed', val: '0.0', unit: 'km/h', lbl: 'Vitesse', cls: 'blue' },
      { id: 'cm-power', val: '--', unit: 'W', lbl: 'Puissance', cls: 'orange' },
      { id: 'cm-kcal', val: '0', unit: 'kcal', lbl: 'Calories', cls: '' },
    ],
    natation: [
      { id: 'cm-laps', val: '0', unit: 'long.', lbl: 'Longueurs', cls: 'green' },
      { id: 'cm-dist', val: '0', unit: 'm', lbl: 'Distance', cls: 'blue' },
      { id: 'cm-pace', val: '--:--', unit: '/100m', lbl: 'Tempo', cls: 'orange' },
      { id: 'cm-kcal', val: '0', unit: 'kcal', lbl: 'Calories', cls: '' },
    ],
  };

  const metrics = metricsMap[sport.id] || [
    { id: 'cm-kcal', val: '0', unit: 'kcal', lbl: 'Calories', cls: 'green' },
    { id: 'cm-time', val: '00:00', unit: '', lbl: 'Durée', cls: 'blue' },
  ];

  el.innerHTML = metrics.map(m => `
    <div class="cardio-metric">
      <div class="cm-value ${m.cls}" id="${m.id}">${m.val}</div>
      <div class="cm-unit">${m.unit}</div>
      <div class="cm-label">${m.lbl}</div>
    </div>
  `).join('');
}

function buildCardioInputs(sport) {
  const el = document.getElementById('cardio-inputs');
  const inputs = sport.inputs || [];

  if (sport.id === 'natation') {
    el.innerHTML = `
      <div class="section-header" style="padding:0 0 10px"><span class="section-title">SAISIE MANUELLE</span></div>
      <div class="cardio-input-row">
        <div class="cardio-input-label">🔄 Longueurs nagées</div>
        <input type="number" inputmode="decimal" class="cardio-input-field" id="input-laps" placeholder="0" oninput="updateSwimCalc()" />
        <div class="cardio-input-unit">x</div>
      </div>
      <div class="cardio-input-row">
        <div class="cardio-input-label">📏 Longueur bassin</div>
        <select class="cardio-input-field" id="input-poolLength" onchange="updateSwimCalc()" style="width:100px">
          <option value="25">25m</option>
          <option value="50">50m</option>
        </select>
        <div class="cardio-input-unit"></div>
      </div>
      <div class="cardio-input-row">
        <div class="cardio-input-label">❤️ FC moy.</div>
        <input type="number" inputmode="decimal" class="cardio-input-field" id="input-heartRate" placeholder="--" />
        <div class="cardio-input-unit">bpm</div>
      </div>
    `;
    return;
  }

  el.innerHTML = inputs.length ? `
    <div class="section-header" style="padding:0 0 10px"><span class="section-title">SAISIE MANUELLE</span></div>
    ${inputs.filter(i => i.unit !== '').map(i => `
      <div class="cardio-input-row">
        <div class="cardio-input-label">${i.label}</div>
        <input type="number" inputmode="decimal" class="cardio-input-field" id="input-${i.key}"
               placeholder="0" step="${i.step || '1'}" oninput="updateCardioFromInput('${i.key}')" />
        <div class="cardio-input-unit">${i.unit}</div>
      </div>
    `).join('')}
  ` : '';
}

function updateCardioFromInput(key) {
  const val = parseFloat(document.getElementById(`input-${key}`)?.value) || 0;
  const sport = activeWorkout ? SPORT_TYPES[activeWorkout.sport] : null;
  if (!sport) return;

  if (key === 'distance') {
    const el = document.getElementById('cm-dist');
    if (el) el.textContent = val.toFixed(1);

    // Calculate pace (running)
    if (sport.id === 'running' && val > 0 && cardioSeconds > 0) {
      const secPerKm = cardioSeconds / val;
      const paceMin = Math.floor(secPerKm / 60);
      const paceSec = Math.round(secPerKm % 60);
      const paceEl = document.getElementById('cm-pace');
      if (paceEl) paceEl.textContent = `${paceMin}:${paceSec.toString().padStart(2,'0')}`;
    }

    // Calculate speed (velo)
    if (sport.id === 'velo' && cardioSeconds > 0) {
      const speedEl = document.getElementById('cm-speed');
      const speed = (val / (cardioSeconds / 3600));
      if (speedEl) speedEl.textContent = speed.toFixed(1);
    }
  }
  if (key === 'speed') {
    const el = document.getElementById('cm-speed');
    if (el) el.textContent = val.toFixed(1);
  }
  if (key === 'power') {
    const el = document.getElementById('cm-power');
    if (el) el.textContent = val;
  }
  updateCardioLiveStats();
}

function updateSwimCalc() {
  const lapsVal = parseInt(document.getElementById('input-laps')?.value) || 0;
  const poolLen = parseInt(document.getElementById('input-poolLength')?.value) || 25;
  const dist = lapsVal * poolLen;

  const lapEl = document.getElementById('cm-laps');
  const distEl = document.getElementById('cm-dist');
  if (lapEl) lapEl.textContent = lapsVal;
  if (distEl) distEl.textContent = dist;

  // Pace per 100m
  if (dist > 0 && cardioSeconds > 0) {
    const secPer100 = (cardioSeconds / dist) * 100;
    const pMin = Math.floor(secPer100 / 60);
    const pSec = Math.round(secPer100 % 60);
    const paceEl = document.getElementById('cm-pace');
    if (paceEl) paceEl.textContent = `${pMin}:${pSec.toString().padStart(2,'0')}`;
  }
  updateCardioLiveStats();
}

function updateCardioLiveStats() {
  const profil = DB.getProfil();
  const kcal = activeWorkout ? estimateKcal(activeWorkout.sport, cardioSeconds, profil.weight) : 0;
  const kcalEl = document.getElementById('cm-kcal');
  if (kcalEl) kcalEl.textContent = kcal;
}

function toggleCardioPause() {
  cardioPaused = !cardioPaused;
  document.getElementById('cardio-pause-btn').textContent = cardioPaused ? '▶️' : '⏸';
}

function addLap() {
  const now = Date.now();
  const lapTime = Math.floor((now - lapStartTime) / 1000);
  lapStartTime = now;
  const totalTime = cardioSeconds;
  laps.push({ num: laps.length + 1, lapTime, totalTime });

  const el = document.getElementById('laps-list');
  if (el.querySelector('.empty-laps')) el.innerHTML = '';

  const row = document.createElement('div');
  row.className = 'lap-row';
  row.innerHTML = `
    <div class="lap-num">#${laps.length}</div>
    <div class="lap-time">${formatTimer(totalTime)}</div>
    <div class="lap-split">+${formatTimer(lapTime)}</div>
  `;
  el.insertBefore(row, el.firstChild);
}

function compileCardioWorkout() {
  const profil = DB.getProfil();
  const sport = SPORT_TYPES[activeWorkout.sport];
  const kcal = estimateKcal(activeWorkout.sport, cardioSeconds, profil.weight);

  // Gather inputs
  const distance = parseFloat(document.getElementById('input-distance')?.value) || null;
  const heartRate = parseFloat(document.getElementById('input-heartRate')?.value) || null;
  const speed = parseFloat(document.getElementById('input-speed')?.value) || null;
  const power = parseFloat(document.getElementById('input-power')?.value) || null;

  // Natation
  const lapsCount = parseInt(document.getElementById('input-laps')?.value) || null;
  const poolLength = parseInt(document.getElementById('input-poolLength')?.value) || 25;
  const swimDist = lapsCount ? lapsCount * poolLength : null;

  Object.assign(activeWorkout, {
    duration: cardioSeconds,
    kcal,
    distance: distance || (swimDist ? swimDist / 1000 : null),
    heartRate,
    speed,
    power,
    laps,
    lapsCount,
    poolLength: lapsCount ? poolLength : null,
    notes: document.getElementById('cardio-notes').value.trim(),
  });

  // Remove nulls
  Object.keys(activeWorkout).forEach(k => activeWorkout[k] === null && delete activeWorkout[k]);

  showSummaryModal();
}

// ===== SUMMARY MODAL =====
function showSummaryModal() {
  const sport = SPORT_TYPES[activeWorkout.sport];
  document.getElementById('summary-emoji').textContent = sport.emoji;
  document.getElementById('summary-sport').textContent = sport.name;
  document.getElementById('summary-title').textContent = 'Séance terminée !';

  buildSummaryStats(activeWorkout);
  currentRating = 0;
  setRatingDisplay(0);
  pendingWorkout = activeWorkout;

  // Reset buttons
  document.querySelector('.summary-save-btn').textContent = '💾 Enregistrer';
  document.querySelector('.summary-save-btn').onclick = saveWorkout;
  document.querySelector('.summary-discard-btn').textContent = 'Annuler';
  document.querySelector('.summary-discard-btn').onclick = discardWorkout;

  openModal('modal-summary');
}

// ===== CONFIRM END =====
function confirmEndWorkout() {
  openModal('modal-confirm');
}

function forceEndWorkout() {
  clearInterval(workoutTimer);
  clearInterval(cardioTimer);
  clearInterval(restTimer);
  activeWorkout = null;
  closeModal('modal-confirm');
  showScreen('screen-home');
}
